﻿namespace TellerWebAPI.DTO
{
    using System.Collections.Generic;
    public class CustomExceptionDTO
    {
        public List<ErrorMessageDTO> ErrorMesages { get; set; }
        public int ResponseCode { get; set; }
    }
}
