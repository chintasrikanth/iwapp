﻿namespace TellerWebAPI.DTO
{
    using System.Collections.Generic;
    public class GenerateReceiptNumberDTO
    {
        public List<ParcelNumbersDTO> ParcelNumberDto { get; set; }
        public List<TenderTypesDTO> TenderTypesDto { get; set; }
        public List<PaymentCategory> PaymentCategoryDto { get; set; }
        public string TransactionNumber { get; set; }
        public decimal? TransactionAmount { get; set; }
        public string TellerReceiptNumber { get; set; }
        public decimal? OverShortAmount { get; set; }

    }
}
