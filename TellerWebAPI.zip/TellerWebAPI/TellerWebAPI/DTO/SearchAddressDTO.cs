﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TellerWebAPI.DTO
{
    public class SearchAddressDTO
    {
        public string SearchText { get; set; }
    }
    public class AddressInputDTO
    {
        public string line_1 { get; set; }
        public string line_2 { get; set; }
        public string line_3 { get; set; }
        public string city { get; set; }
        public int province_state_cd { get; set; }
        public string subtype { get; set; }
        public string zip_postal_code { get; set; }        

    }

}
