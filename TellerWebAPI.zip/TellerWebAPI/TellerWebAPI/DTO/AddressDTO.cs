﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TellerWebAPI.DTO
{
    public class AddressDTO
    {
        public int AddressId { get; set; }
        public string Address { get; set; }
    }
}
