﻿

namespace TellerWebAPI.DTO
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("parameter")]
    public class parameter
    {
        [Key]
        public int id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string data_type { get; set; }
        public string value { get; set; }
        public string tax_year { get; set; }
        public DateTime eff_from_date { get; set; }
        public DateTime eff_to_date { get; set; }
        public DateTime mod_date { get; set; }
        public int category_cd { get; set; }
        public int gov_unit_cd { get; set; }
    }
}
