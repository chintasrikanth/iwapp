﻿namespace TellerWebAPI.DTO
{
    public class TenderTypesDTO
    {

        public string TenderType { get; set; }
        public decimal TenderAmount { get; set; }
        public string paidby { get; set; }
        public int paidbyAddrId { get; set; }
    }
}
