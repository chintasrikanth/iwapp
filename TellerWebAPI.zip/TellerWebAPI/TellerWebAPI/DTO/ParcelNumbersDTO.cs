﻿
namespace TellerWebAPI.DTO
{
    public class ParcelNumbersDTO
    {
        public string ParcelNumbers { get; set; }
        public decimal TaxAmount { get; set; }
        public string TaxYear { get; set; }

    }
}
