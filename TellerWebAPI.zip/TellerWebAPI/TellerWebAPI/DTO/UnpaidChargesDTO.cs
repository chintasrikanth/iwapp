﻿namespace TellerWebAPI.DTO
{
    public class UnpaidChargesDTO
    {
        public string ParcelNumber { get; set; }
        public string taxyear { get; set; }
        public int categoryId { get; set; }
        public string taxdesc { get; set; }
        public string district { get; set; }
        public decimal amtassessed { get; set; }
        public decimal mindue { get; set; }
        public string paying { get; set; }
        public decimal totaldue { get; set; }
        public string pname { get; set; }
        public string paddress { get; set; }
       
    }
}




