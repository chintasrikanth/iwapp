﻿namespace TellerWebAPI.DTO
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class UnPaidChargesInputDTO
    {
        public List<string> ParcelNumbers { get; set; }
        
        public DateTime? InterestDate { get; set; }

    }
}
