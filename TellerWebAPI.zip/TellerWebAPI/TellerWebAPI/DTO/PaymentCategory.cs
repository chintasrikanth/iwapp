﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TellerWebAPI.DTO
{
    public class PaymentCategory
    {
        public string ParcelNumbers { get; set; }
        public string TaxYear { get; set; }
        public string District { get; set; }
        public int CategoryId { get; set; }        
        public decimal Categoryamount { get; set; }

    }
}
