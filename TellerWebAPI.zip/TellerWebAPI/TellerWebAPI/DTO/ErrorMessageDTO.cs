﻿namespace TellerWebAPI.DTO
{
    public class ErrorMessageDTO
    {
        public string Message { get; set; }
    }
}
