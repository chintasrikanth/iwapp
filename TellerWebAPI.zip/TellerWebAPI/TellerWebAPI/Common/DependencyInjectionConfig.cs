﻿
namespace TellerWebAPI.Common
{

    using Microsoft.Extensions.DependencyInjection;
    using TellerWebAPI.DAL;
    using TellerWebAPI.IDAL;

    public class DependencyInjectionConfig
    {

        public static void AddScope(IServiceCollection serviceCollection)
        {
            serviceCollection.AddScoped<ITellerDAL,TellerDAL>();
        }

    }
}
