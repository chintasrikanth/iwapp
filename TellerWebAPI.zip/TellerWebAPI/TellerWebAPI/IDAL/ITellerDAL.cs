﻿

namespace TellerWebAPI.IDAL
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using TellerWebAPI.DTO;

    public interface ITellerDAL
    {

        Task<List<UnpaidChargesDTO>> GetUnpaidCharges(UnPaidChargesInputDTO unPaidCharges);

        Task<string> GetReceiptNumber(GenerateReceiptNumberDTO generateReceiptNumber);

        Task<string> GetCountyName();

        ICollection<Store> GetStores(Func<Store, bool> filter, bool includeCustomers = false);
        ICollection<Customer> GetCustomers(int storeId);
        Customer AddCustomer(Customer customer);

    }
}
