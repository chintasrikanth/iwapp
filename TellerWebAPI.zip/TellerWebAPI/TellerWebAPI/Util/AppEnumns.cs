﻿namespace TellerWebAPI.Util
{
    public static class AppEnumns
    {
        public enum StatuCodes
        {
            UnauthorizedStatusCode = 401,
            UnHandledExceptionOcured=6001,
            BusinessValidationFailed=6002,
            SucessResponseCode=6000,
            UnProcessableEntity=422

        }
    }
}
