﻿namespace TellerWebAPI.Util
{
    using Microsoft.Extensions.Configuration;
    public static class AppSettingsHelpers
    {
        public static IConfigurationRoot config = null;

        private const string DatabaseConnectionStringKey = "AppSettings:DatabaseConnectionString";
        private const string APISecretKey = "AppSettings:SecretKey";

        public static string DatabaseConnectionString { get { return config[DatabaseConnectionStringKey]; } }

        public static string SecretAPIKey { get { return config[APISecretKey]; } }
    }
}
