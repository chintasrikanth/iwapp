﻿namespace TellerWebAPI.Util
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Net.Http;
    using System.Numerics;
    using System.Reflection;
    using System.Security.Cryptography;
    using System.Text;
    using System.Text.Json;
    using System.Threading.Tasks;

    public static class HelperMethods
    {
        private static readonly HttpClient client = new HttpClient();

        public static async Task<T> GetDataFromRestAPI<T>(string ApiUrl)
        {
            try
            {
                client.DefaultRequestHeaders.Accept.Clear();
                var streamData = client.GetStreamAsync(ApiUrl);
                var result = await JsonSerializer.DeserializeAsync<T>(await streamData);
                return result;
            }
            catch (Exception ex)
            {
                return default(T);
            }
        }



        public static DataTable ConvertToDataTable<T>(this List<T> dataList) where T : class
        {
            DataTable convertedTable = new DataTable();
            PropertyInfo[] propertyInfo = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in propertyInfo)
            {
                convertedTable.Columns.Add(prop.Name);
            }
            foreach (T item in dataList)
            {
                var row = convertedTable.NewRow();
                var values = new object[propertyInfo.Length];
                for (int i = 0; i < propertyInfo.Length; i++)
                {
                    var test = propertyInfo[i].GetValue(item, null);
                    row[i] = propertyInfo[i].GetValue(item, null);
                }
                convertedTable.Rows.Add(row);
            }
            return convertedTable;
        }


        public static long ConvertDateTimeToUnix(DateTime dateTime)
        {
            long unixTime = (long)(dateTime.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            return unixTime;
        }

        public static async Task<string> CreateApiKey()
        {
            var bytes = new byte[256 / 8];
            using (var random = RandomNumberGenerator.Create())
                random.GetBytes(bytes);
            return  ToBase62String(bytes);
        }

        private static string ToBase62String(byte[] toConvert)
        {
            const string alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*())+=-~";
            BigInteger dividend = new BigInteger(toConvert);
            var builder = new StringBuilder();
            while (dividend != 0)
            {
                dividend = BigInteger.DivRem(dividend, alphabet.Length, out BigInteger remainder);
                builder.Insert(0, alphabet[Math.Abs(((int)remainder))]);
            }
            return builder.ToString();
        }

    }
}
