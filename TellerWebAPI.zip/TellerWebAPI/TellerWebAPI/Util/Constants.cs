﻿namespace TellerWebAPI.Util
{
    public static class Constants
    {

        public static string DbConnectionString = "";

        public  const string APISecretKeyName = "SecretKey";

        public  const int SQLServerRaiseErrorClass =11;
    }
}
