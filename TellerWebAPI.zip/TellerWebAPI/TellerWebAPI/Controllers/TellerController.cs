﻿namespace TellerWebAPI.Controllers
{
    using TellerWebAPI.DTO;
    using TellerWebAPI.IDAL;
    using TellerWebAPI.Filters;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using TellerWebAPI.Util;
    using System.Collections.Generic;
    using System;

    [Route("[controller]")]
    [ApiController]
    [SecretKey]
    public class TellerController : BaseController
    {

        private ITellerDAL _tellerData;

        public TellerController(ITellerDAL tellerData)
        {
            _tellerData = tellerData;
        }

        [HttpPost]
        [Route("GetUnpaidCharges")]
        public async Task<IActionResult> GetUnpaidCharges([FromBody] UnPaidChargesInputDTO unPaidCharges)
        {
            if (unPaidCharges.InterestDate == null)
            {
                ModelState.AddModelError("InterestDate", "Interest Date Required");
            }
            if (unPaidCharges.ParcelNumbers.Count == 0)
            {
                ModelState.AddModelError("ParcelNumbers", "Parcel Numbers Required");
            }
            if (!ModelState.IsValid)
            {
                return Ok(new APIBadRequestRespnse(ModelState));
            }
            var unpaidcharges = await _tellerData.GetUnpaidCharges(unPaidCharges);
            return Ok(new { responseCode = AppEnumns.StatuCodes.SucessResponseCode, response = unpaidcharges });
        }

        [HttpPost]
        [Route("GenerateReceiptNumber")]
        public async Task<IActionResult> GenerateReceiptNumber([FromBody] GenerateReceiptNumberDTO generateReceiptNumber)
        {

            if (generateReceiptNumber.ParcelNumberDto.Count == 0)
            {
                ModelState.AddModelError("ParcelNumbers", "Parcel Numbers Required");
            }
            if (generateReceiptNumber.TenderTypesDto.Count == 0)
            {
                ModelState.AddModelError("TenderType", "Tender Types Required");
            }
            if (string.IsNullOrEmpty(generateReceiptNumber.TransactionNumber))
            {
                ModelState.AddModelError("TransactionNumber", "Transaction Number Required");
            }
            if (string.IsNullOrEmpty(generateReceiptNumber.TellerReceiptNumber))
            {
                ModelState.AddModelError("ReceiptNumber", "ReceiptNumber Number Required");
            }
            if (generateReceiptNumber.TransactionAmount == null)
            {
                ModelState.AddModelError("TransactionAmount", "Transaction Amount Required");
            }
            if (!ModelState.IsValid)
            {
                return Ok(new APIBadRequestRespnse(ModelState));
            }
            string receiptNumber = null;
            receiptNumber = await _tellerData.GetReceiptNumber(generateReceiptNumber);
            return Ok(new { responseCode = AppEnumns.StatuCodes.SucessResponseCode, response = new { recieptNumber = receiptNumber } });
        }

        [HttpPost]
        [Route("GenerateReceiptNumber/GetAddress")]
        public IActionResult GetAddress([FromBody] SearchAddressDTO searchAddressDTO)
        {
            Random r = new Random();
            int num = r.Next(800751);
            int num1 = r.Next(800751);
            List<AddressDTO> addressDTOs = new List<AddressDTO>
            {
                 new AddressDTO { AddressId = num, Address = searchAddressDTO.SearchText +" SAGE TRAIL RD # 15 MOXEE"},
                 new AddressDTO { AddressId = num1, Address = searchAddressDTO.SearchText +" 12980 YAKIMA VALLEY HWY                           "},
            };

            return Ok(new { responseCode = AppEnumns.StatuCodes.SucessResponseCode, response = new { addressDetails = addressDTOs } });
        }

        [HttpPost]
        [Route("GenerateReceiptNumber/SaveAdress")]
        public IActionResult SaveAdress([FromBody] AddressInputDTO addressInputDTO)
        {
            Random r = new Random();
            int num = r.Next(1000);

            List<AddressDTO> addressDTOs = new List<AddressDTO>
            {
                 new AddressDTO { AddressId = 800751+num, Address = addressInputDTO.line_1+' '+addressInputDTO.line_2+' '+addressInputDTO.line_3+' '+addressInputDTO.zip_postal_code+' '+addressInputDTO.province_state_cd+' '+addressInputDTO.city},
            };

            return Ok(new { responseCode = AppEnumns.StatuCodes.SucessResponseCode, response = new { addressDetails = addressDTOs } });
        }
       
    }
}
