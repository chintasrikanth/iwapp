﻿

namespace TellerWebAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    public class BaseController : ControllerBase
    {
       
    }
}
