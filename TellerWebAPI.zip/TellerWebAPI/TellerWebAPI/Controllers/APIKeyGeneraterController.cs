﻿

namespace TellerWebAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TellerWebAPI.Filters;
    using TellerWebAPI.Util;


    [Route("api/[controller]")]
    [ApiController]
    [SecretKey]
    public class APIKeyGeneraterController : BaseController
    {
        [HttpGet]
        [Route("GetGeneratedSecreateKey")]
        public async Task<IActionResult> GetGeneratedSecreateKey()
        {
            string SecreateKey = await HelperMethods.CreateApiKey();
            return Ok(new { responseCode = AppEnumns.StatuCodes.SucessResponseCode, SecreateKey = SecreateKey });
        }
    }
}
