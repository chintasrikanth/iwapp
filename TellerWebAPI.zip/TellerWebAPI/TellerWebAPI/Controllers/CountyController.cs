﻿namespace TellerWebAPI.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;

    [ApiController]
    [Route("[controller]")]
    public class CountyController : BaseController
    {
        public const string CountryCodeHeaderName = "x-test-country-code";


        private ITellerDAL _tellerData;

       
        public CountyController(ITellerDAL tellerData)
        {
            _tellerData = tellerData;
        }

        [HttpGet]
        public async Task<IActionResult> GetStores()
        {
            var header = Request.Headers[CountryCodeHeaderName];
            Store store = new Store();
            store.CountryCode = header.ToString();
            if (!IsCorrectheader())
            {
                return Unauthorized();
            }
            Func<Store, bool> stores = r => r.CountryCode == header.ToString();
            var result = _tellerData.GetStores(stores);
            if (result == null)
            {
                return Unauthorized();
            }           
            return Ok(result);

            //var countyName = await _tellerData.GetCountyName();
            //return Ok(new { responseCode = AppEnumns.StatuCodes.SucessResponseCode, CountyName = countyName });
        }
        private bool IsSingleHeader(IHeaderDictionary headers, string key)
        {
            return headers.ContainsKey(key) && headers[key].Count() == 1;
        }
        private bool IsCorrectheader()
        {
            var header = Request.Headers[CountryCodeHeaderName];
            if (string.IsNullOrWhiteSpace(header) || !IsSingleHeader(Request.Headers, CountryCodeHeaderName))
            {
                return false;
            }
            return true;
        }
        static int MaximumPossible(int num, int digit)
        {
            // edge case
            if (num == 0)
            {
                return digit * 10;
            }

            // -1 if num is negative number else 1
            int negative = num / Math.Abs(num);
            // get the absolute value of given number
            num = Math.Abs(num);
            int n = num;
            // maximum number obtained after inserting digit.
            int maxVal = int.MinValue;
            int counter = 0;
            int position = 1;

            // count the number of digits in the given number.
            while (n > 0)
            {
                counter++;
                n = n / 10;
            }

            // loop to place digit at every possible position in the number,
            // and check the obtained value.
            for (int i = 0; i <= counter; i++)
            {
                int newVal = ((num / position) * (position * 10)) + (digit * position) + (num % position);

                // if new value is greater the maxVal
                if (newVal * negative > maxVal)
                {
                    maxVal = newVal * negative;
                }

                position = position * 10;
            }

            return maxVal;
        }
        [HttpGet]
        public async Task<IActionResult> GetCustomers(int storeId)
        {
            var header = Request.Headers[CountryCodeHeaderName];
            Func<Store, bool> stores = r => r.StoreId == storeId;
            var result = _tellerData.GetStores(stores);
            if (result == null)
            {
                return NotFound();
            }
            var iscountrycode = result.Where(s => s.CountryCode == header);

            if(iscountrycode == null)
            {
                return Forbid();
            }
            
            return Ok(result);

            //var countyName = await _tellerData.GetCountyName();
            //return Ok(new { responseCode = AppEnumns.StatuCodes.SucessResponseCode, CountyName = countyName });
        }

        [HttpGet]
        public async Task<IActionResult> AddCustomer(Customer _customer)
        {
            var customer = new Customer();
           var header = Request.Headers[CountryCodeHeaderName];
            Store store = new Store();
            store.CountryCode = header.ToString();
            if (string.IsNullOrWhiteSpace(header) || !IsSingleHeader(Request.Headers, CountryCodeHeaderName))
            {
                return Unauthorized();
            }
            var valid = ModelState.IsValid;
            if (valid)
            {
                customer = _tellerData.AddCustomer(_customer);
                if (customer == null)
                {
                    return BadRequest();
                }
            }
            return Ok(customer);

            //var countyName = await _tellerData.GetCountyName();
            //return Ok(new { responseCode = AppEnumns.StatuCodes.SucessResponseCode, CountyName = countyName });
        }
       
    }
    
}
