﻿namespace TellerWebAPI.Controllers
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using TellerWebAPI.DTO;
    using NLog;
    using System;
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Diagnostics;
    using System.Net;
    using Microsoft.Data.SqlClient;
    using TellerWebAPI.Util;
    using TellerWebAPI.Logging;
    [AllowAnonymous]
    public class ErrorController : BaseController
    {
        private static readonly Logger logger = LogManager.GetCurrentClassLogger();

        [Route("/error")]
       public IActionResult ErrorLocalDevelopement()
        {
            CustomExceptionDTO customExceptionDTO = new CustomExceptionDTO();
            var feature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            var exception = feature?.Error;
            HttpStatusCode status = HttpStatusCode.InternalServerError;
            bool execeptionHanled = false;

            if(exception.GetType() == typeof(SqlException) && ((SqlException)exception).Class == Constants.SQLServerRaiseErrorClass)
            {
                status = HttpStatusCode.PreconditionFailed;
                execeptionHanled = true;
            }
            if(exception.GetType() == typeof(UnauthorizedAccessException))
            {
                status = HttpStatusCode.Unauthorized;
                execeptionHanled = true;
            }
            if (exception.GetType() == typeof(NotImplementedException))
            {
                status = HttpStatusCode.NotImplemented;
                execeptionHanled = true;
            }
           
            if (execeptionHanled)
            {
                string exceptionMessage = string.Empty;
                var errorKeys = exception.Message.Split(',');
                customExceptionDTO.ErrorMesages = new List<ErrorMessageDTO>();

                for (int i = 0; i < errorKeys.Length; i++)
                {
                    if (errorKeys[i].Trim().Length == 0)
                        continue;
                    exceptionMessage = errorKeys[i];
                    
                    customExceptionDTO.ErrorMesages.Add(new ErrorMessageDTO { Message = exceptionMessage });
                }
                customExceptionDTO.ResponseCode = (int)AppEnumns.StatuCodes.BusinessValidationFailed;
                if (status == HttpStatusCode.Unauthorized)
                {
                    customExceptionDTO.ResponseCode = (int)AppEnumns.StatuCodes.UnauthorizedStatusCode;
                }
                if (string.IsNullOrEmpty(exceptionMessage))
                {
                    customExceptionDTO.ErrorMesages.Add(new ErrorMessageDTO { Message = "Technical issues" });
                }
                WriteLogException(exception, exception.GetType().ToString());
                return new ObjectResult(customExceptionDTO) { StatusCode = (int)HttpStatusCode.OK };
            }

            LogException(exception);
            WriteLogException(exception, exception.GetType().ToString());
            customExceptionDTO.ErrorMesages = new List<ErrorMessageDTO>();
            customExceptionDTO.ResponseCode = (int)AppEnumns.StatuCodes.UnHandledExceptionOcured;
            customExceptionDTO.ErrorMesages.Add(new ErrorMessageDTO { Message = "Technical issues" });
            return new ObjectResult(customExceptionDTO) { StatusCode = (int)HttpStatusCode.OK };


        }
        public ActionResult LogError(string exceptionMessage)
        {
            LogException(new Exception(exceptionMessage));
           
            return Ok("Error Logged");
        }
        private void LogException(Exception ex)
        {            
            logger.Error(ex, ex.StackTrace);
        }
        private void WriteLogException(Exception ex, string execptiontype)
        {
            
            Logging.LogException(ex, execptiontype);
            ErrorLog.LogException(ex);
        }
    }   

}
