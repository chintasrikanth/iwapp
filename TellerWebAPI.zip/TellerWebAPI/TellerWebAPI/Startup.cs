namespace TellerWebAPI
{
    using System.IO;
    using TellerWebAPI.Util;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using TellerWebAPI.Common;

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        readonly string MyAllowSpecificOrigings = "allowSpecificOrigins";
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // read configuration values from app settings file
            AppSettingsHelpers.config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json").Build();


            // data base connection initiation
            Constants.DbConnectionString = AppSettingsHelpers.DatabaseConnectionString;

            //dependency injection
            DependencyInjectionConfig.AddScope(services);

            services.AddCors(o => o.AddPolicy(MyAllowSpecificOrigings, builder =>
              {
                  builder.AllowAnyOrigin()
                      .AllowAnyMethod()
                      .AllowAnyHeader();
              }
            ));

            services.AddControllers();
            //services.AddHttpsRedirection(options =>
            //{
            //    options.RedirectStatusCode = StatusCodes.Status307TemporaryRedirect;
            //    options.HttpsPort = 5001;
            //});
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseExceptionHandler("/error");
            }
            else
            {
                app.UseExceptionHandler("/error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseCors(MyAllowSpecificOrigings);

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });          


        }
    }
}
