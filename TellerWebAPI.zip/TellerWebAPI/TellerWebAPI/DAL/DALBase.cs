﻿namespace TellerWebAPI.DAL
{
    using TellerWebAPI.Data;
    public abstract class DALBase
    {

        private ApplicationDataContext dataContext;

        protected ApplicationDataContext DbContext
        {
            get { return dataContext ?? (dataContext = new ApplicationDataContext()); }
        }

    }
}
