﻿namespace TellerWebAPI.DAL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using TellerWebAPI.IDAL;
    using TellerWebAPI.DTO;
    using StoredProcedureEFCore;
    using System.Data;
    using TellerWebAPI.Util;
    using Microsoft.Data.SqlClient;
    using TellerWebAPI.Data;
    public class TellerDAL : DALBase, ITellerDAL
    {
        public async Task<List<UnpaidChargesDTO>> GetUnpaidCharges(UnPaidChargesInputDTO unPaidCharges)
        {
            List<UnpaidChargesDTO> listUnPaidCharges = new List<UnpaidChargesDTO>();

            string parcelNumbers = string.Join(",", unPaidCharges.ParcelNumbers);

            await DbContext.LoadStoredProc("dbo.GetBunpaidcharges")
                .AddParam("tIndata", parcelNumbers)
                .AddParam("pAsofDate", unPaidCharges.InterestDate)
                .ExecAsync(async c => listUnPaidCharges = await c.ToListAsync<UnpaidChargesDTO>());

            return listUnPaidCharges;
        }


        public async Task<string> GetReceiptNumber(GenerateReceiptNumberDTO generateReceiptNumber)
        {
            try
            {
                string RecieptNumber = string.Empty;

                DataTable parceNumbersDTO = generateReceiptNumber.ParcelNumberDto.ConvertToDataTable<ParcelNumbersDTO>();
                DataTable tenderTypesDTO = generateReceiptNumber.TenderTypesDto.ConvertToDataTable<TenderTypesDTO>();
                DataTable paymentCategoryDTO = generateReceiptNumber.PaymentCategoryDto.ConvertToDataTable<PaymentCategory>();

                var parcelNumersData = new SqlParameter()
                {
                    ParameterName = "ParcelNumbers",
                    SqlDbType = SqlDbType.Structured,
                    Value = parceNumbersDTO,
                    TypeName = "UT_ParcelNumbers",
                    Direction = ParameterDirection.Input
                };
                var tendertypeData = new SqlParameter()
                {
                    ParameterName = "TenderTypes",
                    SqlDbType = SqlDbType.Structured,
                    Value = tenderTypesDTO,
                    TypeName = "UT_TenderType",
                    Direction = ParameterDirection.Input
                };
                var paymentCategory = new SqlParameter()
                {
                    ParameterName = "PmtCategory",
                    SqlDbType = SqlDbType.Structured,
                    Value = paymentCategoryDTO,
                    TypeName = "UT_PmtCategory",
                    Direction = ParameterDirection.Input
                };

                var outparam = new SqlParameter
                {
                    ParameterName = "preceipt_id_out",
                    DbType = System.Data.DbType.String,
                    Size = Int32.MaxValue,
                    Direction = System.Data.ParameterDirection.Output
                };
                await DbContext.LoadStoredProc("dbo.GenerateRecieptNumber")
                .AddParam(parcelNumersData)
                .AddParam(tendertypeData)
                .AddParam(paymentCategory)
                .AddParam("TransactionNumber", generateReceiptNumber.TransactionNumber)
                .AddParam("TransactionAmount", generateReceiptNumber.TransactionAmount)
                .AddParam("OverShortAmount", generateReceiptNumber.OverShortAmount)
                .AddParam("TellerReceiptNumber", generateReceiptNumber.TellerReceiptNumber)                 
                .AddParam(outparam)
                .ExecNonQueryAsync();

                RecieptNumber = Convert.ToString(outparam.Value);

                return RecieptNumber;
            }
            catch (Exception ex)
            {

                throw;
            }


        }

        public async Task<string> GetCountyName()
        {
            string countyName = string.Empty;
            ApplicationDataContext appDataContext = new ApplicationDataContext();
            var Parmerters = (appDataContext.parameters.Where(T => T.name == "COUNTY_NAME")).Select(T => T.value);
            countyName =  Parmerters.FirstOrDefault();
            return countyName;
        }

    }
}
