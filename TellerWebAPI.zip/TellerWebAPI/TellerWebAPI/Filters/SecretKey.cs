﻿namespace TellerWebAPI.Filters
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Threading.Tasks;
    using TellerWebAPI.DTO;
    using TellerWebAPI.Util;

    [AttributeUsage(validOn: AttributeTargets.Class)]
    public class SecretKey : Attribute, IAsyncActionFilter
    {
        CustomExceptionDTO customExceptionDTO = new CustomExceptionDTO();

        private const string APIKEYNAME = Constants.APISecretKeyName;
        public async Task OnActionExecutionAsync
               (ActionExecutingContext context, ActionExecutionDelegate next)
        {
            if (!context.HttpContext.Request.Headers.TryGetValue
                (APIKEYNAME, out var extractedApiKey))
            {
                customExceptionDTO.ErrorMesages = new List<ErrorMessageDTO>();
                customExceptionDTO.ResponseCode = (int)AppEnumns.StatuCodes.UnauthorizedStatusCode;
                customExceptionDTO.ErrorMesages.Add(new ErrorMessageDTO { Message = "Not authorized" });
                context.Result = new ObjectResult(customExceptionDTO) { StatusCode = (int)HttpStatusCode.Unauthorized };
                return;
            }



            var apiKey = AppSettingsHelpers.SecretAPIKey;

            if (!apiKey.Equals(extractedApiKey))
            {
                customExceptionDTO.ErrorMesages = new List<ErrorMessageDTO>();
                customExceptionDTO.ResponseCode = (int)AppEnumns.StatuCodes.UnauthorizedStatusCode;
                customExceptionDTO.ErrorMesages.Add(new ErrorMessageDTO { Message = "Not authorized" });
                context.Result = new ObjectResult(customExceptionDTO) { StatusCode = (int)HttpStatusCode.Unauthorized };
                return;
            }

            await next();
        }
    }
}
