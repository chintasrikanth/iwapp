using System;

namespace TellerWebAPI
{
    public class County
    {
       

        public string CountyName { get; set; }
    }
}
