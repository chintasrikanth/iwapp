﻿namespace TellerWebAPI.Data
{

    using Microsoft.EntityFrameworkCore;
    using TellerWebAPI.Util;
    using TellerWebAPI.DTO;

    public partial class ApplicationDataContext:DbContext
    {

        public ApplicationDataContext()
        {

        }

        public ApplicationDataContext(DbContextOptions<ApplicationDataContext> options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(Constants.DbConnectionString);
        }
        public DbSet<parameter> parameters { get; set; }

    }
}
