﻿

namespace TellerWebAPI.Logging
{
    using System;
    public static class Logging
    {
        private static string GenerateDefaultLogFileName(string BaseFileName)
        {
            return AppDomain.CurrentDomain.BaseDirectory + "\\" + BaseFileName + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Year + ".log";
        }

        public static void LogException(Exception ex, string pSql)
        {
            string message = $"'{ex.Message}'";
            if (ex.InnerException != null)
            {
                message += $" : '{ex.InnerException.Message}'";
            }
            message += $" : '{ex.StackTrace}'";

            if (pSql != null)
            {
                message = message + " SQL: " + pSql;
            }
            string appName = "ManatronWS";
            string filename = GenerateDefaultLogFileName(appName);
             WriteToLog(filename, message);
            //if (Convert.ToBoolean(ConfigurationManager.AppSettings["WriteEventLog"]))
            //{
            //    WriteToEventLog(appName, message, System.Diagnostics.EventLogEntryType.Error);
            //}

            //if (Convert.ToBoolean(ConfigurationManager.AppSettings["WriteTextLog"]))
            //{
            //    string filename = GenerateDefaultLogFileName(appName);
            //    WriteToLog(filename, message);
            //}
        }

        public static void LogException(Exception ex)
        {
            LogException(ex, null);
        }

        public static void LogDebugInfo(string pMessage)
        {
            string filename = GenerateDefaultLogFileName("ManatronWS");
            WriteToLog(filename, pMessage);
        }

        private static void WriteToLog(string LogPath, string Message)
        {
            System.IO.StreamWriter s = null;
            try
            {
                s = System.IO.File.AppendText(LogPath);
                s.WriteLine(DateTime.Now + "\t" + Message);
                s.WriteLine();
                s.WriteLine();
                s.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        private static void WriteToEventLog(string Source, string Message, System.Diagnostics.EventLogEntryType EntryType)
        {
            try
            {
                if (!System.Diagnostics.EventLog.SourceExists(Source))
                {
                    System.Diagnostics.EventLog.CreateEventSource(Source, "Application");
                }
                System.Diagnostics.EventLog.WriteEntry(Source, Message, EntryType);
            }
            catch
            {
                throw;
            }
        }
    }
}
