﻿

namespace TellerWebAPI.Logging
{
    using System;
    using System.Text;
    /// <summary>
    /// Generic Error Logging class
    /// </summary>
    public class ErrorLog
    {
        /// <summary>
        /// Error Log Folder Path
        /// </summary>
        private static string ErrorLogFolderPath = string.Empty;

        /// <summary>
        /// Error Log File Path
        /// </summary>
        private static string ErrorLogFilePath = string.Empty;

        /// <summary>
        /// Generate the Error Log folder and FileName
        /// </summary>
        private static void GenerateErrorFileName()
        {
            if (string.IsNullOrEmpty(ErrorLogFilePath))
            {
                ErrorLogFolderPath = $@"{AppDomain.CurrentDomain.BaseDirectory}logs\";
            }

            if (string.IsNullOrEmpty(ErrorLogFilePath))
            {
                ErrorLogFilePath = $"{ErrorLog.ErrorLogFolderPath}log_{DateTime.Now.ToString("yyyyMMdd")}.html";
            }
        }
        
        /// <summary>
        /// Write Error Log for the exception
        /// </summary>
        /// <param name="ex">Exception thrown by the application</param>
        /// <param name="Condition">Any additional condition that might help to debug more</param>
        public static void LogException(Exception ex, string Condition = "")
        {
            try
            {
                GenerateErrorFileName();

                bool isNew = false;

                if (!System.IO.Directory.Exists(ErrorLogFolderPath))
                {
                    System.IO.Directory.CreateDirectory(ErrorLogFolderPath);
                }

                if (!System.IO.File.Exists(ErrorLogFilePath))
                {
                    isNew = true;
                }

                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(new System.IO.FileStream(ErrorLogFilePath, System.IO.FileMode.Append, System.IO.FileAccess.Write)))
                {
                    StringBuilder stringBuilder = new StringBuilder();

                    if (isNew)
                    {
                        stringBuilder.Append("<table border='1' cellspacing='1' width='100%' style='font-size:12px; font-family: Verdana;'>");
                        stringBuilder.Append("<tr>");
                        stringBuilder.Append("<th>Date Time</th>");
                        stringBuilder.Append("<th>Error</th>");
                        stringBuilder.Append("<th>Inner Exception</th>");
                        stringBuilder.Append("<th>Stack Trace</th>");
                        stringBuilder.Append("<th>Condition</th>");
                    }

                    stringBuilder.Append("<tr>");
                    stringBuilder.Append($"<td>{DateTime.Now.ToString("MM/dd/yyyy hh:mm tt")}</td>");
                    stringBuilder.Append($"<td>{ex.Message}</td>");

                    string InnerExceptionMessage = string.Empty;
                    if (ex.InnerException != null)
                    {
                        InnerExceptionMessage = ex.InnerException.Message;
                    }
                    stringBuilder.Append($"<td>{InnerExceptionMessage}</td>");
                    stringBuilder.Append($"<td>{ex.StackTrace}</td>");
                    stringBuilder.Append($"<td>{Condition}</td>");
                    stringBuilder.Append($"</tr>");

                    sw.WriteLine("");
                    sw.WriteLine(stringBuilder.ToString());
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception exe)
            {
                throw exe;
            }
        }

        /// <summary>
        /// Write Error Log for the exception
        /// </summary>
        /// <param name="ex">Exception thrown by the application</param>
        /// <param name="Condition">Any additional condition that might help to debug more</param>
        public static void Log(string message)
        {
            try
            {
                GenerateErrorFileName();

                bool isNew = false;

                if (!System.IO.Directory.Exists(ErrorLogFolderPath))
                {
                    System.IO.Directory.CreateDirectory(ErrorLogFolderPath);
                }

                if (!System.IO.File.Exists(ErrorLogFilePath))
                {
                    isNew = true;
                }

                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(new System.IO.FileStream(ErrorLogFilePath, System.IO.FileMode.Append, System.IO.FileAccess.Write)))
                {
                    StringBuilder stringBuilder = new StringBuilder();

                    if (isNew)
                    {
                        stringBuilder.Append("<table border='1' cellspacing='1' width='100%' style='font-size:12px; font-family: Verdana;'>");
                        stringBuilder.Append("<tr>");
                        stringBuilder.Append("<th>Date Time</th>");
                        stringBuilder.Append("<th>Error</th>");
                        stringBuilder.Append($"</tr>");
                    }

                    stringBuilder.Append("<tr>");
                    stringBuilder.Append($"<td>{DateTime.Now.ToString("MM/dd/yyyy hh:mm tt")}</td>");
                    stringBuilder.Append($"<td>{message}</td>");

                    string InnerExceptionMessage = string.Empty;
                    stringBuilder.Append($"</tr>");

                    stringBuilder.Append($"</table>");

                    sw.WriteLine("");
                    sw.WriteLine(stringBuilder.ToString());
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
